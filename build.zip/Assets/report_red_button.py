class Component:
    def __init__(self):
        self.REPORT_RED_BUTTON_COOLDOWN = 45_000

    def input(self, action):
        # print("red button press")
        if action == "left_click":
            # print("left click red button")
            self.press()

    def update(self, event):
        pass

    def should_render(self):
        return True

    def render(self):
        pass

    def get_elapsed_ms(self):
        last_used_time = getDouble(f"last_report_red_button_time", 0)
        return getTime() - last_used_time        

    def get_player_count(self):
        return int(getDouble("player_count", 1.0))
    
    def press(self):
        # Cooldown logic
        if self.get_elapsed_ms() < self.REPORT_RED_BUTTON_COOLDOWN:
            # print("fail press() because of cooldown")
            return
        
        # Switch to voting screen
        setDouble("last_report_red_button_time", getTime())
        setString("vote_type", "button")
        setString("map", "vote")

