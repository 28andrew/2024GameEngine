class Component:
    def input(self, action):
        if getPlayerId() == self.get_sprite_player():
            # Controlling own sprite
            # print(f'Player {getPlayerId()} pressed {action}')

            status = getString(f"status_{getPlayerId()}", "alive")
            if status != "alive" and status != "gone":
                return

            x_off = 0
            y_off = 0
            if action == "Left":
                x_off = -10
            elif action == "Right":
                x_off = 10
            elif action == "Down":
                y_off = 10
            elif action == "Up":
                y_off = -10
            
            x = getSpriteX()
            y = getSpriteY()
            if doesOverlapWithMap(x, y, x_off, y_off):
                return

            setSpriteX(x + x_off)
            setSpriteY(y + y_off)
            # print(f"get_sprite_player: {self.get_sprite_player()}, x_off: {x_off}, y_off: {y_off}")

    def update(self, event):
        pass

    def should_render(self):
        return self.get_sprite_player() < self.get_player_count() and getString(f"status_{self.get_sprite_player()}", "alive") != "gone"

    def render(self):
        pass

    def get_sprite_player(self):
        return int(getSpriteName()[len("player"):])
    
    def get_player_count(self):
        return int(getDouble("player_count", 1.0))