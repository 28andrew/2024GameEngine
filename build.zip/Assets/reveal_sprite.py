import math
from collections import defaultdict

class Component:
    def input(self, action):
        pass

    def update(self, event):
        pass

    def should_render(self):
        return True

    def render(self):
        killed_player = int(getDouble("killed_player", 0))
        role = getString(f"role_{killed_player}", "")
        text = f"RIP Player {killed_player}. They were {role}."
        
        renderTextColored(text, 30, 60, 300, 255, 255, 255, 255)