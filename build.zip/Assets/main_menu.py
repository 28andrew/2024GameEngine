class Component:
    def input(self, action):
        pass

    def update(self, event):
        pass