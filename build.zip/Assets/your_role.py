class Component:
    def input(self, action):
        pass

    def update(self, event):
        if event == "load":
            print("Loaded your role screen")
            scheduleEvent("roles_done", 5 * 1000)
        elif event == "roles_done":
            print("Roles done")
            setString("map", "ship")