#!/usr/bin/env zsh
if [[ -z "$ZSH_VERSION" ]]; then
    exec bash "$0" "$@"
fi

# TO BE PACKAGED in build.zip

python_version=$(python3 -V 2>&1 | awk '{print $2}')

if [[ "$python_version" == 3.10.* || "$python_version" == 3.11.* ]]; then
    echo "Python version is good: $python_version"
else
    echo "Python version is not compatible: $python_version. Please use Python 3.10.x or 3.11.x."
    exit 1
fi

source pyd_set_env_vars.sh python3 || {
    echo "Failed to source pyd's pyd_set_env_vars.sh"
    exit 1
}

./sus || {
    echo "Failed to start game"
    exit 1
}