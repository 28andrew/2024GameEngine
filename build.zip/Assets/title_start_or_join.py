import random

class Component:
    def input(self, action):
        if getPlayerId() == 0 and action == "left_click":
            # Start game
            self.start_game()

    def update(self, event):
        # setSpriteX(random.randint(0,400))
        pass

    def should_render(self):
        return True

    def render(self):
        playerCount = self.get_player_count()
        renderText(f"Start ({playerCount})", 30, 0, 15)

    # Helpers
    def get_player_count(self):
        return int(getDouble("player_count", 1.0))

    def start_game(self):
        players = self.get_player_count()
        if players < 2:
            return
        
        print("Starting game...")
        
        pirate_count = 0
        if players <= 5:
            pirate_count = 1
        elif 5 <= players <= 9:
            pirate_count = 2
        else:
            pirate_count = 3
        
        # Assign roles
        roles = ["sailor"] * (players - pirate_count)
        roles.extend(["pirate"] * pirate_count)
        random.shuffle(roles)

        if players == 2:
            # For testing, as 2 players is useless anyways
            roles = ["pirate", "sailor"]

        for i, role in enumerate(roles):
            print(f"Role {i}: {role}")
            setString(f"role_{i}", role)

        # Show roles
        setString("map", "your_role")
