class Component:
    def __init__(self):
        self.alive_players = []
        self.dead_players = []
    
    def input(self, action):
        pass

    def update(self, event):
        if event == "load":
            setDouble("vote_start_time", getTime())

            for player in self.get_alive_players():
                setDouble(f"player{player}_vote", -1)
    
    def get_vote_time_elapsed_ms(self):
        return getTime() - getDouble("vote_start_time", getTime())

    def get_all_players(self):
        return list(range(self.get_player_count()))
    
    def get_alive_players(self):
        return [player for player in self.get_all_players() if self.is_alive(player)]
    
    def get_dead_players(self):
        return [player for player in self.get_all_players() if not self.is_alive(player)]

    def is_alive(self, player):
        return getString(f"status_{player}", "alive") == "alive"

    def get_player_count(self):
        return int(getDouble("player_count", 1.0))
