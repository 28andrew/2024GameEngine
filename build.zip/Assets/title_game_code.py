class Component:
    def input(self, action):
        print(f"Input {action} from player {getPlayerId()}")
        # scheduleEvent("test", 1000)

    def update(self, event):
        # if event:
            # print(f"Update {event}")
        pass

    def should_render(self):
        return True

    def render(self):
        renderText("Game Code:", 20, 0, 0)
        renderText(getString("game_key", ""), 30, 0, 20)