class Component:
    def input(self, action):
        pass

    def update(self, event):
        pass

    def should_render(self):
        return True

    def render(self):
        winner = getString("winner", "?")
        pirates = []
        for player in self.get_all_players():
            if getString(f"role_{player}", "sailor") == "pirate":
                pirates.append(f"Player {player}")

        text = f"Congratulations {winner}."
        renderTextColored(text, 30, 60, 300, 255, 255, 255, 255)
        text2 = f"The pirates were {', '.join(pirates)}."
        renderTextColored(text2, 30, 60, 350, 255, 255, 255, 255)
    
    def get_player_count(self):
        return int(getDouble("player_count", 1.0))

    def get_all_players(self):
        return list(range(self.get_player_count()))