import math

class Component:
    def __init__(self):
        self.KILL_COOLDOWN = 30_000 # ms
        self.KILL_RANGE = 300 # pixels
    
    def input(self, action):
        if getString(f"status_{getPlayerId()}", "alive") != "alive":
            return

        if action == "K" or action == "left_click":
            # print("calling press()")
            self.press()

    def update(self, event):
        pass

    def should_render(self):
        if getString(f"status_{getPlayerId()}", "alive") != "alive":
            return False

        return getString(f"role_{getPlayerId()}", "") == "pirate"

    def render(self):
        elapsed_ms = self.get_elapsed_ms()
        cooldown = ""
        if (elapsed_ms) < self.KILL_COOLDOWN:
            cooldown = f"({int(self.KILL_COOLDOWN - elapsed_ms) // 1000 + 1})"
        renderText(f"Kill{cooldown}", 25, 0, 20)

    def get_elapsed_ms(self):
        last_used_time = getDouble(f"kill_last_used_{getPlayerId()}", 0)
        return getTime() - last_used_time        

    def press(self):
        # Cooldown logic
        if self.get_elapsed_ms() < self.KILL_COOLDOWN:
            # print("fail press() because of cooldown")
            return
        
        # Look for nearby players
        player_to_kill = self.get_closest_killable_player()
        if player_to_kill is None:
            # print("fail press() because of no one near")
            return
    
        # Kill player and update cooldown
        setString(f"status_{player_to_kill}", "dead")
        setString(f"sprite_player{player_to_kill}_texturePath", "player_dead.bmp")
        setDouble(f"kill_last_used_{getPlayerId()}", getTime())
        self.win_logic()

    def win_logic(self):
        pirateCount = 0
        sailorCount = 0
        for player in self.get_alive_players():
            role = getString(f"role_{player}", "sailor")
            if role == "pirate":
                pirateCount += 1
            elif role == "sailor":
                sailorCount += 1
        
        if pirateCount >= sailorCount:
            # WIN
            setString("winner", "pirate")
            setString("map", "end")


    def getDistance(self, playerX, playerY):
        x, y = getOtherSpritePosition(f"player{getPlayerId()}")
        # print(f"i'm at {x}, {y}, other player is at {playerX}, {playerY}")
        return math.sqrt((playerX - x) ** 2 + (playerY - y) ** 2)

    def get_closest_killable_player(self) -> int | None:
        closest_player = None
        closest_distance = float('inf')
        for player in range(self.get_player_count()):
            if player == getPlayerId() or getString(f"status_{player}", "alive") != "alive":
                # Can't kill self or already killed player
                continue

            playerX, playerY = getOtherSpritePosition(f"player{player}")
            distance = self.getDistance(playerX, playerY)
            # print(f"other player{player} is {distance} away")
            if distance <= self.KILL_RANGE and distance < closest_distance:
                closest_player = player
                closest_distance = distance
        
        return closest_player

    def get_player_count(self):
        return int(getDouble("player_count", 1.0))
    
    def get_all_players(self):
        return list(range(self.get_player_count()))
    
    def get_alive_players(self):
        return [player for player in self.get_all_players() if self.is_alive(player)]
    
    def get_dead_players(self):
        return [player for player in self.get_all_players() if not self.is_alive(player)]

    def is_alive(self, player):
        return getString(f"status_{player}", "alive") == "alive"

