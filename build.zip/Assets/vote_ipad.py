import math
from collections import defaultdict

class Component:
    def __init__(self):
        self.VOTING_TIME = 60_000
        self.DEBOUNCE_PERIOD = 250

    def input(self, action):
        elapsed_ms = getTime() - getDouble(f"ipad_vote_{getPlayerId()}_last_use", 0)
        if elapsed_ms < self.DEBOUNCE_PERIOD:
            return
        setDouble(f"ipad_vote_{getPlayerId()}_last_use", getTime())

        if getString(f"status_{getPlayerId()}", "alive") != "alive":
            return

        # current_vote is an idx
        current_vote = int(getDouble(f"player{getPlayerId()}_vote", -1))
        # No vote selected yet, pick the first one
        if current_vote == -1 and (action == "Left" or action == "Right"):
            setDouble(f"player{getPlayerId()}_vote", 0)
            return
        
        # Next vote
        if action == "Right":
            voteIdxOffset = 1
        elif action == "Left":
            voteIdxOffset = -1
        else:
            return
        
        voteIdx = current_vote
        voteIdx += voteIdxOffset
        if voteIdx < 0:
            voteIdx = len(self.get_alive_players()) - 1
        elif voteIdx >= len(self.get_alive_players()):
            voteIdx = 0
        setDouble(f"player{getPlayerId()}_vote", voteIdx)

    def update(self, event):
        # Check if time elapsed is vote over, then transition to reveal or back to game
        elapsed = self.get_vote_time_elapsed_ms()
        alive_players = self.get_alive_players()
        if elapsed >= self.VOTING_TIME:
            # Vote over
            majority_required = int(math.ceil(len(alive_players) / 2.0))
            
            counts = defaultdict(int)
            for player in alive_players:
                voted_for_idx = int(getDouble(f"player{player}_vote", 0))
                voted_for = alive_players[voted_for_idx]
                counts[voted_for] += 1
            
            winner = None
            for player, count in counts.items():
                if count >= majority_required:
                    winner = player
                    break

            if winner is not None:
                # Reveal screen
                setDouble("killed_player", winner)
                setString(f"status_{winner}", "gone")
                setString("map", "reveal")
            else:
                # Back to ship
                setString("map", "ship")


    def win_logic(self):
        pass

    def should_render(self):
        return True

    def render(self):
        print(f"test, alive players{self.get_alive_players()}")
        current_vote = int(getDouble(f"player{getPlayerId()}_vote", -1))
        MAX_COLS = 3
        COLORS = [
            (159, 155, 155, 255),
            (148, 62, 23, 255),
            (153, 111, 35, 255),
            (152, 155, 48, 255),
            (107, 153, 44, 255),
            (77, 153, 43, 255),
            (68, 153, 48, 255),
            (68, 153, 82, 255)
        ]
        
        dead = [(f"Player {player}") for player in self.get_dead_players()]
        renderText(f"Dead: {', '. join(dead)}", 25, 15, 15)

        if getString("vote_type", "report") == "report":
            reporting = int(getDouble("reporting_player", 0.0))
            reported = int(getDouble("reported_player", 0.0))
            renderText(f"Player {reporting} reported player {reported}'s body", 25, 15, 45)
        
        x = 15
        y = 100
        for i, player in enumerate(self.get_alive_players()):
            # print(f"i={i}, player={player}, x={x}, y={y}")
            text = f"Player {player}"
            if i == current_vote:
                text = f"[{text}]"
            r, g, b, a = COLORS[player]
            #void renderTextColored(string text, int size, int offsetX, int offsetY, int r, int g, int b, int a)
            renderTextColored(text, 30, x, y, r, g, b, a)

            if (i - 2) % MAX_COLS == 0:
                y += 50
            x += 300

    def get_player_count(self):
        return int(getDouble("player_count", 1.0))

    def get_all_players(self):
        return list(range(self.get_player_count()))
    
    def get_alive_players(self):
        return [player for player in self.get_all_players() if self.is_alive(player)]
    
    def get_dead_players(self):
        return [player for player in self.get_all_players() if not self.is_alive(player)]

    def is_alive(self, player):
        return getString(f"status_{player}", "alive") == "alive"

    def get_vote_time_elapsed_ms(self):
        return getTime() - getDouble("vote_start_time", getTime())
