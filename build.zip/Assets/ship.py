class Component:
    def input(self, action):
        pass

    def update(self, event):
        n_players = self.get_player_count()
        if event == "load":
            for player in range(n_players):
                # Teleport to spawn
                setOtherSpriteX(f"player{player}", 3900)
                setOtherSpriteY(f"player{player}", 3900)
                
                # Reset kill cooldowns
                setDouble(f"kill_last_used_{player}", getTime())

                # Change dead => gone
                if getString(f"status_{player}", "") == "dead":
                    setString(f"status_{player}", "gone")

            # Reset button cooldown
            setDouble("last_report_red_button_time", getTime())
        else:
            for player in range(n_players):
                playerX, playerY = getOtherSpritePosition(f"player{player}")
                setDouble(f"view_ship_{player}_x", playerX + (110 / 2))
                setDouble(f"view_ship_{player}_y", playerY + (180 / 2))

    def get_player_count(self):
        return int(getDouble("player_count", 1.0))