class Component:
    def input(self, action):
        pass

    def update(self, event):
        pass

    def should_render(self):
        return True

    def render(self):
        role = getString(f"role_{getPlayerId()}", "?")
        renderText(role, 30, 0, 20)