import math

class Component:
    def __init__(self):
        self.REPORT_RANGE = 300

    def input(self, action):
        if action == "left_click" or action == "R":
            self.press()

    def update(self, event):
        pass

    def should_render(self):
        if self.get_dead_player_nearby() is not None:
            return True
        return False

    def render(self):
        pass

    def get_player_count(self):
        return int(getDouble("player_count", 1.0))
    
    def getDistance(self, playerX, playerY):
        x, y = getOtherSpritePosition(f"player{getPlayerId()}")
        # print(f"i'm at {x}, {y}, other player is at {playerX}, {playerY}")
        return math.sqrt((playerX - x) ** 2 + (playerY - y) ** 2)
    
    def get_dead_player_nearby(self):
        closest_player = None
        closest_distance = float('inf')
        for player in range(self.get_player_count()):
            if player == getPlayerId() or getString(f"status_{player}", "alive") != "dead":
                continue

            playerX, playerY = getOtherSpritePosition(f"player{player}")
            distance = self.getDistance(playerX, playerY)
            # print(f"other player{player} is {distance} away")
            if distance <= self.REPORT_RANGE and distance < closest_distance:
                closest_player = player
                closest_distance = distance
        
        return closest_player
    

    
    def press(self):
        dead_player = self.get_dead_player_nearby()
        if dead_player is None:
            return
        
        setDouble("reporting_player", getPlayerId())
        setDouble("reported_player", dead_player) 
        setString("vote_type", "report")
        setString("map", "vote")

