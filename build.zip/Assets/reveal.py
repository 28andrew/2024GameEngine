class Component:
    def input(self, action):
        pass

    def update(self, event):
        if event == "load":
            scheduleEvent("back_to_ship", 10_000)
        elif event == "back_to_ship":
            pirateCount = 0
            sailorCount = 0
            for player in self.get_alive_players():
                role = getString(f"role_{player}", "sailor")
                if role == "pirate":
                    pirateCount += 1
                elif role == "sailor":
                    sailorCount += 1
            
            if pirateCount >= sailorCount:
                # WIN
                setString("winner", "pirate")
                setString("map", "end")
            elif pirateCount == 0:
                # WIN FOR sailors
                setString("winner", "sailor")
                setString("map", "end")
            else:
                # NO WIN YET
                setString("map", "ship")

    def get_player_count(self):
        return int(getDouble("player_count", 1.0))
    
    def get_all_players(self):
        return list(range(self.get_player_count()))
    
    def get_alive_players(self):
        return [player for player in self.get_all_players() if self.is_alive(player)]
    
    def get_dead_players(self):
        return [player for player in self.get_all_players() if not self.is_alive(player)]

    def is_alive(self, player):
        return getString(f"status_{player}", "alive") == "alive"